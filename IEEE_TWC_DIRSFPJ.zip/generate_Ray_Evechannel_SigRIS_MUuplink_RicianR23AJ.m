function [hAJ,Hd,G,Hr,path_AJ,path_g,path_r,path_d,noise] = generate_Ray_Evechannel_SigRIS_MUuplink_RicianR23AJ(N,M,K,eb1,eb2)
%%    
AP = [0,0,2];%% AP Location
IRS(1,:) = [0,2,2]; %DIRS Location
AJ = [20,160,0]; % AJ Location

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% LU Locations %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Rai = 10;
Tha = 2*pi*(rand(1,K));
rad = Rai*rand(1,K);
Dar1  = 0;
Dar2 = 160;
Pt = zeros(K,3);
for kk = 1:K
    Pt(kk,:) = [Dar1+rad(kk)*cos(Tha(kk)),Dar2+rad(kk)*sin(Tha(kk)),0];
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
noise = -170+10*log10(180*1e3);% Noise Power

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% AP-DIRS Channel %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
IRS_angle = 0;
Random_ang = (pi)*(rand(1,N));
G_LOS = zeros(N,M);
d_g = sqrt(sum(abs(AP-IRS).^2));
Lg = 35.6 + 22*log10(d_g);
path_g = 10.^((-Lg-noise/2)/10); % large-scale channel fading coefficients
pg = sqrt(path_g);
G_NLOS = sqrt(1/2).*(randn(N,M)+1j.*randn(N,M));
for  r = 1:N
    for n = 1:M
        G_LOS(r,n) = exp(1j*pi*(n-1)*sin(IRS_angle+Random_ang(r)));
    end
end
G = eb1.*G_LOS+eb2.*G_NLOS;
G = pg.*G;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% DIRS-LU Channel %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Hr_sig = sqrt(1/2).*(randn(K,N)+1j.*randn(K,N));
for k = 1:K
    dr(k) = sqrt(sum(abs(Pt(k,:)-IRS).^2));
    Lr(k) = 32.6 + 36.7*log10(dr(k));
    path_r(k) = 10.^((-Lr(k)-noise/2)/10); %large-scale channel fading coefficients
    pr(k) = sqrt(path_r(k));
    Hr(k,:) = pr(k).*Hr_sig(k,:);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% AP-LU Channel %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for k = 1:K
    dk(k) = sqrt(sum(abs(Pt(k,:)-AP).^2)); 
    Ld(k) = 32.6 + 36.7*log10(dk(k)) ; 
    path_d(k) = 10.^((-Ld(k)-noise)/10); %large-scale channel fading coefficients
    pd(k) = sqrt(path_d(k));
    Hd(k,:)=sqrt(1/2).*(randn(1,M)+1j.*randn(1,M));
    Hd(k,:) = pd(k).*Hd(k,:);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% AJ-LU Channels %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
dAJ = sqrt(sum(abs(AP-AJ).^2)); 
LAJ = 32.6 + 36.7*log10(dAJ) ; 
path_AJ = 10.^((-LAJ-noise)/10); %large-scale channel fading coefficients
pAJ = sqrt(path_AJ);
widehAJ = sqrt(1/2).*(randn(1,M)+1j.*randn(1,M));
hAJ = pAJ.*widehAJ;

