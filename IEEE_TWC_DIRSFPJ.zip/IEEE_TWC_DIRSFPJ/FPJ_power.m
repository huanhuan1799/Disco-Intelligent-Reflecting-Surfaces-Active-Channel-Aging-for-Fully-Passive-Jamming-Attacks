close all; clear all; clc
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  Simulation parameters %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
rng('shuffle'); %Initiate the random number generators with a random seed
%%If rng('shuffle'); is not supported by your Matlab version, you can use
%%the following commands instead:
%randn('state',sum(100*clock));

Nr = 1;%MU-MISO
K = 24; %Number of LUs
Nantennas = [256]; %Number of Transmit Antennas
N = Nantennas;
N_ite = 2000; %Number of realizations in the Monte Carlo simulations 
NN = [4096];

PdBm = [-22:4:10]; %Transmit Power,dB scale  
AJ1_dB = -4; % Active Jamming Power, dB
AJ2_dB = 4; % dB

PAJ1 = (10.^(AJ1_dB/10)) ;
PAJ2 = (10.^(AJ2_dB/10)) ;
P = (10.^(PdBm/10)) ; %Linear scale
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Initialization %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
weights = ones(K,1);
sumRateZF_wo = zeros(N_ite,length(PdBm));
sumRateZF_wo_LB = zeros(N_ite,length(PdBm));

sumRateZF_pro = zeros(N_ite,length(PdBm));
sumRateZF_pro_LB = zeros(N_ite,length(PdBm));

sumRateZF_wAJ1 = zeros(N_ite,length(PdBm));
sumRateZF_wAJ2 = zeros(N_ite,length(PdBm));
sumRateZF_wAJ_LB = zeros(N_ite,length(PdBm));

sumRateMRC_wo = zeros(N_ite,length(PdBm));
sumRateMRC_wo_LB = zeros(N_ite,length(PdBm));

sumRateMRC_pro = zeros(N_ite,length(PdBm));
sumRateMRC_pro_LB = zeros(N_ite,length(PdBm));
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Go Through All Channel Realizations %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    for m = 1:N_ite
        m  
         eb = 10; eb22 = 1/(1+eb); eb11 = eb/(1+eb); eb1 = sqrt(eb11); eb2 = sqrt(eb22);
         NN1 = NN; 
         [hAJ,Hd1,Gr1,Hr1,pAJ,pg,pr,pd,noise] = generate_Ray_Evechannel_SigRIS_MUuplink_RicianR23AJ(NN1,N,K,eb1,eb2);%% Channel Generation 

         for np = 1:length(PdBm)
             PP = P(np);
             Hd = Hd1';
             Hcom1 = Hd;
             pharam = exp(pi*1j*(randi(2,1,NN1)-1));
             Hris2 = (Hr1*diag(pharam))*Gr1;
             Hris22 = Hris2';
             Hcom2 = Hris22+Hd;
             %%%%%%%%%%%%%%%%%%%%%%%%%% ZF w/o Jamming %%%%%%%%%%%%%%%%%%%%%%%%%%
             W1 = Hd;
             channelGains = abs(W1'*Hd).^2;
             signalGains = diag(channelGains);
             interferenceGains = sum(channelGains,2)-signalGains;
             noiseterm = diag(W1'*W1);
             rates = log2(1+ (PP)*signalGains./( (PP)*interferenceGains+noiseterm));
             Lossdsum = sum(pd);
             sumRateMRC_wo(m,np) = weights'*rates;
             for k = 1:K
                 sumRateMRC_wo_LB(m,np) = sumRateMRC_wo_LB(m,np) + log2(1+(  (PP)*(N-1)*pd(k) )/( (PP)*(Lossdsum-pd(k)) + 1 ) );
             end
             clear W1 channelGains signalGains interferenceGains rates Noiseterm Lossdsum
             
             %%%%%%%%%%%%%%%%%%%%%%%%%% DIRS-FPJ & MRC && Derived LB in (17) %%%%%%%%%%%%%%%%%%%%%%%%%%
             Wpro1 = Hcom1;
             channelGains = abs(Wpro1'*Hcom1).^2;
             signalGains = diag(channelGains);
             interferenceGains = sum(channelGains,2) - signalGains;
             Jammingterm = sum(abs(Wpro1'*(Hcom2-Hcom1)).^2,2);
             noiseterm = diag(Wpro1'*Wpro1);
             rates = log2(1+( (PP)*signalGains)./( (PP)*interferenceGains + noiseterm + (PP)*Jammingterm) );
             sumRateMRC_pro(m,np) = weights'*rates;
             LossTotal1 = sum(pg.*pr);
             Lossdsum = sum(pd);
             for k = 1:K
                 sumRateMRC_pro_LB(m,np) = sumRateMRC_pro_LB(m,np) + log2(1+( (PP)*(N-1)*pd(k))/( (PP)*((NN1)*LossTotal1) + (PP)*(Lossdsum-pd(k)) + 1));
             end
             clear Lossdsum LossTotal1 Wpro1 channelGains signalGains interferenceGains rates noiseterm Jammingterm
             %%%%%%%%%%%%%%%%%%%%%%%%%% MRC LB in [28] %%%%%%%%%%%%%%%%%%%%%%%%%%
             W1 = Hd*pinv(Hd'*Hd);
             channelGains = abs(W1'*Hd).^2;
             signalGains = diag(channelGains);
             interferenceGains = sum(channelGains,2)-signalGains;
             noiseterm = diag(W1'*W1);
             rates = log2(1+ (PP)*signalGains./( PP*interferenceGains + noiseterm ) );
             sumRateZF_wo(m,np) = weights'*rates;
             for k = 1:K
                 sumRateZF_wo_LB(m,np) = sumRateZF_wo_LB(m,np) + log2(1+ (PP)*(N-K)*pd(k));
             end
             clear W1 channelGains signalGains interferenceGains rates noiseterm
             %%%%%%%%%%%%%%%%%%%%%%%%%% AJ w/ -4 dBm && AJ w/ 4dBm %%%%%%%%%%%%%%%%%%%%%%%%%%
             W1 = (Hd*pinv(Hd'*Hd))';
             for k = 1:K
                 signalgain = abs(W1(k,:)*Hd(:,k))^2;
                 interferenceGains = abs(W1(k,:)*hAJ')^2;
                 noiseterm = diag(W1*W1');
                 sumRateZF_wAJ1(m,np) =  sumRateZF_wAJ1(m,np) + log2(1+ ((PP)*signalgain)/( (PAJ1)*interferenceGains + noiseterm(k)) );
             end
             clear  signalGains interferenceGains
             
             for k = 1:K
                 sumRateZF_wAJ_LB(m,np) = sumRateZF_wAJ_LB(m,np) + log2(1+( (PP*(N-K)*pd(k) )/( PAJ1*pAJ+1)) );
             end
             clear W1 channelGains signalGains interferenceGains rates noiseterm

             W1 = (Hd*pinv(Hd'*Hd))';
             for k = 1:K
                 signalgain = abs(W1(k,:)*Hd(:,k))^2;
                 interferenceGains = abs(W1(k,:)*hAJ')^2;
                 noiseterm = diag(W1*W1');
                 sumRateZF_wAJ2(m,np) =  sumRateZF_wAJ2(m,np) + log2(1+ ((PP)*signalgain)/( (PAJ2)*interferenceGains + noiseterm(k)) );
             end
             clear  signalGains interferenceGains W1 channelGains signalGains interferenceGains rates noiseterm 
              %%%%%%%%%%%%%%%%%%%%%%%%%% DIRS-FPJ & ZF && Derived LB in (18) %%%%%%%%%%%%%%%%%%%%%%%%%%
             Wpro1 = Hcom1*pinv(Hcom1'*Hcom1);
             channelGains = abs(Wpro1'*Hcom1).^2;
             signalGains = diag(channelGains);
             interferenceGains = sum(channelGains,2) - signalGains;
             Jammingterm = sum(abs(Wpro1'*(Hcom2-Hcom1)).^2,2);
             noiseterm = diag(Wpro1'*Wpro1);
             rates = log2(1+ (PP)*signalGains./( (PP)*interferenceGains+noiseterm+ (PP)*Jammingterm));
             sumRateZF_pro(m,np) = weights'*rates;
             LossTotal = sum(pg*pr);
             for k = 1:K
                 sumRateZF_pro_LB(m,np) = sumRateZF_pro_LB(m,np) + log2(1+( (PP)*((N-K)*pd(k)))/(1+ (PP)*(NN1)*LossTotal));
             end
             clear Lossdsum LossTotal Wpro1 channelGains signalGains interferenceGains rates Noiseterm Jammingterm
         end
        
    end


        

%Plot simulation results
clc;close all
figure; hold on; box on;
%% MU
plot(PdBm,mean(sumRateZF_wo/K(:,:),1),'k*','LineWidth',1.8,'MarkerSize',8);
hold on; box on;
plot(PdBm,mean(sumRateZF_wo_LB/K(:,:),1),'k-.','LineWidth',1.8,'MarkerSize',8);
hold on; box on;

plot(PdBm,mean(sumRateZF_wAJ1/K(:,:),1),'bh','LineWidth',1.8,'MarkerSize',8);
hold on; box on;
plot(PdBm,mean(sumRateZF_wAJ2/K(:,:),1),'b^','LineWidth',1.8,'MarkerSize',8);
hold on; box on;
%plot(PdBm,mean(sumRateZF_wAJ_LB/K(:,:),1),'c-.','LineWidth',1.8,'MarkerSize',8);
%hold on; box on;


plot(PdBm,mean(sumRateZF_pro/K(:,:),1),'ms','LineWidth',1.8,'MarkerSize',8);
hold on; box on;
plot(PdBm,mean(sumRateZF_pro_LB/K(:,:),1),'m-','LineWidth',1.8,'MarkerSize',8);
hold on; box on;


plot(PdBm,mean(sumRateMRC_wo/K(:,:),1),'kp','LineWidth',1.8,'MarkerSize',8);
hold on; box on;
plot(PdBm,mean(sumRateMRC_wo_LB/K(:,:),1),'k:','LineWidth',1.8,'MarkerSize',8);
hold on; box on;

plot(PdBm,mean(sumRateMRC_pro/K(:,:),1),'mo','LineWidth',1.8,'MarkerSize',8);
hold on; box on;
plot(PdBm,mean(sumRateMRC_pro_LB/K(:,:),1),'m--','LineWidth',1.8,'MarkerSize',8);
hold on; box on;



%axis([-20,10,0,14])
legend('ZF w/o Jamming','ZF LB in [28]','AJ w/ -4 dBm','AJ w/ 4dBm','DIRS-FPJ & ZF','Derived LB in (18)','MRC w/o Jamming','MRC LB in [28]','DIRS-FPJ & MRC','Derived LB in (17)','Location','Best');
axis([-22,10,0,14]);
xlabel('Average Transmitted Power [dBm]')
ylabel('Ergodic Uplink Rrate [bits/symbol/per user]');